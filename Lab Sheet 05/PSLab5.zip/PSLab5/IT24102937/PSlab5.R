setwd("C:\\Users\\Shanthi\\Desktop\\PSLab5\\IT24102937")
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)
names(Delivery_Times) <- c("X1")  

delivery_times <- Delivery_Times$X1
breaks <- seq(20, 70, length.out = 10)

# Show histogram
hist(delivery_times,
     breaks = breaks,
     right = FALSE,
     col = "lightblue",
     border = "black",
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency")

# Cumulative Frequency Polygon (Ogive)
freq_table <- hist(delivery_times,
                   breaks = breaks,
                   right = FALSE,
                   plot = FALSE)

cum_freq <- cumsum(freq_table$counts)

plot(freq_table$breaks[-1], cum_freq, type = "o",
     col = "red", pch = 16, lwd = 2,
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency")
