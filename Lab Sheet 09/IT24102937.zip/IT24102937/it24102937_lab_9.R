setwd("C:\\Users\\Shanthi\\Desktop\\PS_lab09\\IT24102937")

# Exercise
pop_mean_bake <- 45
pop_sd_bake <- 2
n_bake <- 25

set.seed(456)
bake_sample <- rnorm(n_bake, mean = pop_mean_bake, sd = pop_sd_bake)
cat("Generated baking time sample (minutes):\n")
print(round(bake_sample, 3))

xbar_b <- mean(bake_sample)
z_b <- (xbar_b - 46) / (pop_sd_bake / sqrt(n_bake))
pval_bake <- pnorm(z_b)   # one-sided less => P(Z <= z)

ci_bake_lower <- xbar_b - qnorm(1 - 0.05/2) * (pop_sd_bake / sqrt(n_bake))
ci_bake_upper <- xbar_b + qnorm(1 - 0.05/2) * (pop_sd_bake / sqrt(n_bake))

cat("\nSample mean (baking):", xbar_b, "\n")
cat("z-statistic (baking):", z_b, "\n")
cat("one-sided p-value (P(Z <= z)):", pval_bake, "\n")
cat("95% CI (using known sigma): [", ci_bake_lower, ",", ci_bake_upper, "]\n")


alpha <- 0.05
if(pval_bake < alpha){
  cat("Conclusion: Reject H0 at alpha =", alpha, "- evidence mean < 46.\n")
} else {
  cat("Conclusion: Do NOT reject H0 at alpha =", alpha, "- insufficient evidence to say mean < 46.\n")
}