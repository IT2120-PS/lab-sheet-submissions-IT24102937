getwd()
setwd("D:\\PS lab07\\it24102937")
#Q1
ex1 <- punif(25,min=0,max=40) - punif(10, min=0, max=40)
ex1

#Q2
lambda_ex2 <- 1/3
ex2 <- pexp(2,rate=lambda_ex2)
ex2

#Q3
mu_iq <- 100
sd_iq <- 15

ex3_i <- 1 - pnorm(130, mean=mu_iq , sd=sd_iq)
ex3_i

ex3_ii <- qnorm(0.95,mean=mu_iq,sd=sd_iq)
ex3_ii