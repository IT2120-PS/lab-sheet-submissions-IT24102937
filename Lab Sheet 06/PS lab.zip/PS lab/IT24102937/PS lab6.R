getwd()
setwd("D:\\PS lab\\IT24102937")
#01
#i. 50 independent students, each with probability 0.85 of passing;X counts the number of passes.
#Here, random variable X has binomial distribution with n=50 and p=0.85


#Probability P(X >= 47)
#Use 1- P(X<= 46) to find P(X>=47)

1-pbinom(46,50,0.85,lower.tail=TRUE)


#02
#i. X=the number of customer calls received by the call center in one hour.

#ii. The distribution of X is a Poisson distribution with mean 12.


x<-15
lambda<-12

dpois(x,lambda)
